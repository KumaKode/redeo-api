module.exports = {
  InfoController: require("./info-controller"),
  CountryController: require("./country-countroller"),
  StateController: require("./state-controller"),
  CityController: require("./city-controller"),
  UserController: require("./user-controller"),
  SkillController: require("./skill-controller"),
  JobSeekerController: require("./jobseeker-controller"),
  EmployerController: require("./employer-controller"),
  SocialLinksController: require("./sociallinks-controller"),
  JobController: require("./job-controller"),
};
