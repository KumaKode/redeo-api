module.exports = {
  ErrorResponse: require("./error-response"),
  SuccessResponse: require("./success-response"),
  Auth: require("./auth"),
};
