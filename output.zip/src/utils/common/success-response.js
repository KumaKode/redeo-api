const success = {
  success: true,
  message: "Sucessfully completed the request",
  data: {},
  error: {},
};

module.exports = success;
